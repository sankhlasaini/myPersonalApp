import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-white-paper-dialog',
  templateUrl: './white-paper-dialog.component.html',
  styleUrls: ['./white-paper-dialog.component.css']
})
export class WhitePaperDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
