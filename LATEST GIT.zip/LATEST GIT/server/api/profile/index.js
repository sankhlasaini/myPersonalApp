const router = require('./profile.router');

module.exports = router;