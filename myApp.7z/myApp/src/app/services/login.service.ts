import { Injectable } from '@angular/core';
import { Http } from "@angular/http";

@Injectable()
export class LoginService {

  constructor(private _http: Http) { }

  login(userForm) {

    return this._http.post('', { email: 'asd', password: 'asd' }).map((res: Response) => {

    })
  }

  getLoginDetails(userForm) {
    console.log(userForm.value.password);
    return this._http.post(`/loginme`, { email: userForm.value.email, password: userForm.value.password })
      .map((res: Response) => {
        const result = res.json();
        console.log("result ----------------", result);
        //console.log(result.userResource.split('||')[1] );
        //return userForm.value.email;
        if (!(result.access_token === undefined)) {
          var object =
            {
              access_token: result.access_token,
              timestamp: (new Date().getTime()) / 3600000,
              expiresIn: result.expires_in / 3600,
              jti: result.jti,
              refresh_token: result.refresh_token,
              token_type: result.token_type,
              orgId: result.userResource.split('||')[1]
            };
          return object;
        }
        else {
          console.log(result);
          return result.error;
        }
      })
  }
}
