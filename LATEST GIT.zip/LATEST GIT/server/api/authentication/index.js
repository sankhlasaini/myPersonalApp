const router = require('./authentication.router');

module.exports = router;