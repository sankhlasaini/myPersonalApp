import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-feed-dialog',
  templateUrl: './news-feed-dialog.component.html',
  styleUrls: ['./news-feed-dialog.component.css']
})
export class NewsFeedDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
