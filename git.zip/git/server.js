// Get dependencies
var express = require("express");
var path = require("path");
var app = express();

var http = require("http").Server(app);
var io = require('socket.io')(http);


var bodyParser = require("body-parser");

var cors = require("cors");


const socketio = require('socket.io');

const socketEvents = require('./server/socket/socket');

// var socket = require("./server/socket/socket");



// MONGO
// var mongo = require('./ConfigFiles/mongo');
var webService = require("./server/services/webapp.service");
var MongoClient = require("mongodb").MongoClient;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// app.use(cookieParser());

// Point static path to dist
app.use(express.static(path.join(__dirname, "dist")));

// Get port from environment and store in Express.
var port = process.env.PORT || "3000";
app.set("port", port);



// socket.io
// testing====================

// testing====================

// create MONGO connections

app = webService.setupMiddlewares(app);

app = webService.setupRestRoutes(app);

webService.setupMongooseConnections();
// mongo.setupMongooseConnections();

// Create HTTP server.
// var server = http.createServer(app);

// Listen on provided port, on all network interfaces.

io.on('connection', function (socket) {
    console.log('a user connected');

    socket.on('chat message', function (msg) {
        console.log('message: ' + msg);
        io.emit('chat message', msg);
    });

    socket.on('disconnect', function () {
        console.log('user disconnected');
    });
});
http.listen(port, () =>
    console.log(`Hey Divesh Server running on localhost:${port}`)
);
