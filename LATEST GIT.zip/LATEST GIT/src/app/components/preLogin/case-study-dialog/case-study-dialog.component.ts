import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-study-dialog',
  templateUrl: './case-study-dialog.component.html',
  styleUrls: ['./case-study-dialog.component.css']
})
export class CaseStudyDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
