import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-speak-dialog',
  templateUrl: './client-speak-dialog.component.html',
  styleUrls: ['./client-speak-dialog.component.css']
})
export class ClientSpeakDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
