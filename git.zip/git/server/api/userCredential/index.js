const router = require('./userCredential.router');

module.exports = router;