My Personal App repo.
Command:

<!-- install node modules -->
npm install

<!-- build app -->
ng build --watch

<!-- start the server -->
node server
