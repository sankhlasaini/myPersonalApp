Deltaverge desktop app repo.
Command:
npm install
ng build

Unix:
    export NODE_ENV=production
Windows:
    SET NODE_ENV=production

node server